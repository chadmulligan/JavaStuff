/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author laz
 */
public class StudentRecord_1 {
    // Declare instance variables.
    private String name;
       
        
    // Constructor that gets single parameter
    public StudentRecord_1(String name){
        this.name = name;
    }
   
        
    /**
     * Returns the name of the student
     */
    public String getName(){
        return name;
    }
}
    
